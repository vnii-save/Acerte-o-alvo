canvas = document.getElementById("canvasJogo");
contexto = canvas.getContext("2d");
nomesImagensEspeciais = [
    "bombardino.png",
    "bombombini.png",
    "cappuccino.png",
    "patapim.png",
    "tralalero.png",
    "tung.png",
    "vaca.png"
];
imagemEspecial = new Image();
imagemEspecial.onload = desenharAlvo;
pontuacao = 0;
alvosAcertados = 0;
x = 0;
y = 0;
area = 34;
raioEspecial = 70;
raioAtual = area;
alvoEspecial = false;
tempoNaTela = 1000;
tempoRestante = tempoNaTela;
contagem = null;
jogoTerminou = false;

canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;
// Função para desenhar um círculo
function desenharCirculo(raio, cor) {
    contexto.beginPath();
    contexto.arc(x, y, raio, 0, Math.PI * 2);
    contexto.fillStyle = cor;
    contexto.fill();
}
// Função para desenhar o alvo
function desenharAlvo() {
    contexto.clearRect(0, 0, canvas.width, canvas.height);

    if (alvoEspecial) {
        if (imagemEspecial.complete && imagemEspecial.naturalWidth > 0) {
            contexto.drawImage(imagemEspecial, x - raioAtual, y - raioAtual, raioAtual * 2, raioAtual * 2);
        }
    } else {
        desenharCirculo(34, "red");
        desenharCirculo(22, "white");
        desenharCirculo(11, "red");
    }
}
// Função para mover o alvo
function moverAlvo() {
    alvoEspecial = alvosAcertados > 0 && alvosAcertados % 10 == 0;
    if (alvoEspecial) {
        var indiceAleatorio = Math.floor(Math.random() * nomesImagensEspeciais.length);
        imagemEspecial.src = "img/" + nomesImagensEspeciais[indiceAleatorio];
    }
    raioAtual = alvoEspecial ? raioEspecial : area;
    x = raioAtual + Math.random() * (canvas.width - raioAtual * 2);
    y = raioAtual + Math.random() * (canvas.height - raioAtual * 2);
    desenharAlvo();

    clearInterval(contagem);
    tempoRestante = tempoNaTela;
    document.getElementById("tempoAlvo").textContent = "1.0";
    contagem = setInterval(function () {
        tempoRestante -= 100;
        document.getElementById("tempoAlvo").textContent = (tempoRestante / 1000).toFixed(1);

        if (tempoRestante <= 0) {
            clearInterval(contagem);
            pontuacao = 0;
            document.getElementById("pontuacao").textContent = 0;
            document.getElementById("mensagemPerda").style.display = "block";
            jogoTerminou = true;
        }
    }, 100);
}
// Evento de clique no canvas
canvas.addEventListener("click", function (evento) {
    retangulo = canvas.getBoundingClientRect();
    cliqueX = evento.clientX - retangulo.left;
    cliqueY = evento.clientY - retangulo.top;

    if (!jogoTerminou && Math.abs(cliqueX - x) < raioAtual && Math.abs(cliqueY - y) < raioAtual) {
        pontuacao += alvoEspecial ? 10 : 1;
        alvosAcertados++;
    } else if (!jogoTerminou) {
        pontuacao--;
    } else {
        return;
    }

    if (!jogoTerminou) {
        document.getElementById("pontuacao").textContent = pontuacao;
        moverAlvo();
    }
});
// Botão de reiniciar o jogo
function reiniciarJogo() {
    pontuacao = 0;
    alvosAcertados = 0;
    jogoTerminou = false;
    document.getElementById("pontuacao").textContent = 0;
    document.getElementById("mensagemPerda").style.display = "none";
    moverAlvo();
}

document.getElementById("botaoResetar").addEventListener("click", reiniciarJogo);
document.addEventListener("keydown", function (evento) {
    if (evento.key.toLowerCase() == "r") {
        reiniciarJogo();
    }
});

moverAlvo();
