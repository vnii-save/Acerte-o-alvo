// Pegando elementos
canvas = document.getElementById("canvasJogo");
contexto = canvas.getContext("2d");
elementoPontuacao = document.getElementById("pontuacao");
elementoTempo = document.getElementById("tempoAlvo");
mensagemPerda = document.getElementById("mensagemPerda");
// Variáveis
// Raio de acerto do alvo
raioAlvo = 34;
// Duração do alvo na tela
duracaoAlvo = 1000;
// Pontuação
pontuacao = 0;
// Contagem de alvos acertador
alvosAcertados = 0;
// Posição do ponteiro
x = 0;
y = 0;
// Alvo especial, começa como false e após 10 acertos vira true e volta a false depois de acertar ou errar o alvo
alvoEspecial = false;
// Tempo de duração do alvo na tela
tempoRestante = duracaoAlvo;
contagem = null;
// Jogo iniciado, começa como false e após acertar o alvo inicial vira true, após o jogador perder volta a false
jogoIniciado = false;
// Termino do jogo, começa como false e após o jogador perder vira true, após o reinicio do jogo volta a false
jogoTerminou = false;
// Largura e altura do canvas
canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;
// Função para desenhar o círculo (Formato do alvo)
function desenharCirculo(raio, cor) {
    contexto.beginPath();
    contexto.arc(x, y, raio, 0, Math.PI * 2);
    contexto.fillStyle = cor;
    contexto.fill();
}
// Função para desenhar o alvo normal e especial
function desenharAlvo() {
    contexto.clearRect(0, 0, canvas.width, canvas.height);
    cor = alvoEspecial ? "#FFD700" : "red";
    desenharCirculo(raioAlvo, cor);
    desenharCirculo(raioAlvo * 2 / 3, "white");
    desenharCirculo(raioAlvo / 3, cor);
}
// Função para mover o alvo
function moverAlvo() {
    alvoEspecial = alvosAcertados > 0 && alvosAcertados % 10 === 0;
    x = raioAlvo + Math.random() * (canvas.width - raioAlvo * 2);
    y = raioAlvo + Math.random() * (canvas.height - raioAlvo * 2);
    desenharAlvo();
// Duração do alvo na tela
    clearInterval(contagem);
    tempoRestante = duracaoAlvo;
    elementoTempo.textContent = (duracaoAlvo / 1000).toFixed(1);
    contagem = setInterval(function () {
        tempoRestante -= 100;
        elementoTempo.textContent = (tempoRestante / 1000).toFixed(1);
// Mensagem de perda após o tempo zerar
        if (tempoRestante <= 0) {
            clearInterval(contagem);
            pontuacao = 0;
            elementoPontuacao.textContent = pontuacao;
            mensagemPerda.style.display = "block";
            jogoTerminou = true;
        }
    }, 100);
}
// Função para mostrar o alvo inicial
function mostrarAlvoInicial() {
    x = canvas.width / 2;
    y = canvas.height / 2;
    alvoEspecial = false;
    desenharAlvo();
}
// Função para o botão de reiniciar o jogo
function reiniciarJogo() {
    clearInterval(contagem);
    pontuacao = 0;
    alvosAcertados = 0;
    jogoIniciado = false;
    jogoTerminou = false;
    elementoPontuacao.textContent = pontuacao;
    elementoTempo.textContent = (duracaoAlvo / 1000).toFixed(1);
    mensagemPerda.style.display = "none";
    mostrarAlvoInicial();
}
// Escutar os cliques e botões (EventListener)
canvas.addEventListener("click", function (evento) {
    if (jogoTerminou) return;
// Formato do alvo
    retangulo = canvas.getBoundingClientRect();
// Onde o jogador clica dentro do canva para acertar o alvo
    cliqueX = (evento.clientX - retangulo.left - canvas.clientLeft)
        * canvas.width / canvas.clientWidth;
    cliqueY = (evento.clientY - retangulo.top - canvas.clientTop)
        * canvas.height / canvas.clientHeight;
// Calculo para saber se o jogador acertou o alvo
    acertouAlvo = Math.hypot(cliqueX - x, cliqueY - y) <= raioAlvo;
// Começar o jogo após acertar o alvo inicial
    if (!jogoIniciado) {
        if (acertouAlvo) {
            jogoIniciado = true;
            moverAlvo();
        }
        return;
    }
// Contagem de ponto se acertou o alvo ganha 1 ponto
    if (acertouAlvo) {
        pontuacao += alvoEspecial ? 10 : 1;
// Ganho de ponto
        alvosAcertados++;
// Contagem de ponto se não acertou o alvo perde 1 ponto
    } else {
// Perca de ponto
        pontuacao--;
    }
// Atualizar a pontuação e mover o alvo após acerto ou erro
    elementoPontuacao.textContent = pontuacao;
    moverAlvo();
});
// Receber o elemento do botão reiniciar
document.getElementById("botaoResetar").addEventListener("click", reiniciarJogo);
// Adicionando o escutador de eventos para teclas e usando função evento (para escutar eventos)
document.addEventListener("keydown", function (evento) {
// Escutar a tecla "R"(EventListener)
    if (evento.key.toLowerCase() === "r") reiniciarJogo();
});
// Mostrar o alvo inicial no início, após reiniciar ou perder
mostrarAlvoInicial();
