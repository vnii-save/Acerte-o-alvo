canvas = document.getElementById("canvasJogo");
contexto = canvas.getContext("2d");
elementoPontuacao = document.getElementById("pontuacao");
elementoTempo = document.getElementById("tempoAlvo");
mensagemPerda = document.getElementById("mensagemPerda");
raioAlvo = 34;
duracaoAlvo = 2000;

pontuacao = 0;
alvosAcertados = 0;
x = 0;
y = 0;
alvoEspecial = false;
tempoRestante = duracaoAlvo;
contagem = null;
jogoIniciado = false;
jogoTerminou = false;

canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;

function desenharCirculo(raio, cor) {
    contexto.beginPath();
    contexto.arc(x, y, raio, 0, Math.PI * 2);
    contexto.fillStyle = cor;
    contexto.fill();
}

function desenharAlvo() {
    contexto.clearRect(0, 0, canvas.width, canvas.height);
    cor = alvoEspecial ? "#FFD700" : "red";
    desenharCirculo(raioAlvo, cor);
    desenharCirculo(raioAlvo * 2 / 3, "white");
    desenharCirculo(raioAlvo / 3, cor);
}

function moverAlvo() {
    alvoEspecial = alvosAcertados > 0 && alvosAcertados % 10 === 0;
    x = raioAlvo + Math.random() * (canvas.width - raioAlvo * 2);
    y = raioAlvo + Math.random() * (canvas.height - raioAlvo * 2);
    desenharAlvo();

    clearInterval(contagem);
    tempoRestante = duracaoAlvo;
    elementoTempo.textContent = (duracaoAlvo / 1000).toFixed(1);
    contagem = setInterval(function () {
        tempoRestante -= 100;
        elementoTempo.textContent = (tempoRestante / 1000).toFixed(1);

        if (tempoRestante <= 0) {
            clearInterval(contagem);
            pontuacao = 0;
            elementoPontuacao.textContent = pontuacao;
            mensagemPerda.style.display = "block";
            jogoTerminou = true;
        }
    }, 100);
}

function mostrarAlvoInicial() {
    x = canvas.width / 2;
    y = canvas.height / 2;
    alvoEspecial = false;
    desenharAlvo();
}

function reiniciarJogo() {
    clearInterval(contagem);
    pontuacao = 0;
    alvosAcertados = 0;
    jogoIniciado = false;
    jogoTerminou = false;
    elementoPontuacao.textContent = pontuacao;
    elementoTempo.textContent = (duracaoAlvo / 1000).toFixed(1);
    mensagemPerda.style.display = "none";
    mostrarAlvoInicial();
}

canvas.addEventListener("click", function (evento) {
    if (jogoTerminou) return;

    retangulo = canvas.getBoundingClientRect();
    cliqueX = (evento.clientX - retangulo.left - canvas.clientLeft)
        * canvas.width / canvas.clientWidth;
    cliqueY = (evento.clientY - retangulo.top - canvas.clientTop)
        * canvas.height / canvas.clientHeight;
    acertouAlvo = Math.hypot(cliqueX - x, cliqueY - y) <= raioAlvo;

    if (!jogoIniciado) {
        if (acertouAlvo) {
            jogoIniciado = true;
            moverAlvo();
        }
        return;
    }

    if (acertouAlvo) {
        pontuacao += alvoEspecial ? 10 : 1;
        alvosAcertados++;
    } else {
        pontuacao--;
    }

    elementoPontuacao.textContent = pontuacao;
    moverAlvo();
});

document.getElementById("botaoResetar").addEventListener("click", reiniciarJogo);
document.addEventListener("keydown", function (evento) {
    if (evento.key.toLowerCase() === "r") reiniciarJogo();
});

mostrarAlvoInicial();
